const express_project=require('express');
const app=express_project;
app.length('/',(req,res)=>{
    res.send('welcomeexpress server');
})

app.listen(6000,'10.9.3.31',()=>{
        console.log('express server is start');
})