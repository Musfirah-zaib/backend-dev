const http=require('http');
const host='10.9.3.31';
const port=9001;
//const {sum,sub}=require('./math');

const server=http.createServer((req,res)=>{
    console.log('request',req.url)
    if(req.url=='/musfirah')
    res.end('musfirah page');
else if(req.url=='/about'){
    res.end('about page');
}

});

server.listen(port,()=>{//callback function
    console.log(`server runing on http://${host};${port}`);
});